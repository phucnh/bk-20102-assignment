﻿//------------------------------------------------------------------------------------------------- 
// <copyright file="Form1.cs" company="Scanmax">
// Copyright (c) Scanmax.  All rights reserved.
// </copyright>
// <summary>Defines the Form1 type.</summary>
//-------------------------------------------------------------------------------------------------

using System.ServiceModel;

namespace StaffInformation
{
    using System;
    using System.Windows.Forms;
    using StaffService;

    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonGetInformation_Click(object sender, EventArgs e)
        {
            var client = new StaffInformationClient();
            try
            {
                Person p = client.GetPerson(Convert.ToInt32(textBoxID.Text));
                dataGrid.DataSource = new[] { p };
            }
            catch (FaultException<CustomFaultMsg> ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }
        }

        private void buttonGetAll_Click(object sender, EventArgs e)
        {
            var client = new StaffInformationClient();
            dataGrid.DataSource = client.GetAll();
        }
    }
}
