﻿//------------------------------------------------------------------------------------------------- 
// <copyright file="StaffInformation.cs" company="Scanmax">
// Copyright (c) Scanmax.  All rights reserved.
// </copyright>
// <summary>Defines the StaffInformation type.</summary>
//-------------------------------------------------------------------------------------------------

namespace FaultContractSample
{
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;

public class StaffInformation : IStaffInformation
{
    private readonly List<Person> personCollection;
    public StaffInformation()
    {
        personCollection = new List<Person>
                               {
                                   new Person { PersonId = 0, FullName = "Trần Văn Anh", Age = 30 },
                                   new Person { PersonId = 1, FullName = "Lý Đào", Age = 35 },
                                   new Person { PersonId = 2, FullName = "Hoàng Văn Giáp", Age = 28 },
                                   new Person { PersonId = 3, FullName = "Nguyễn Quang Cường", Age = 25 },
                                   new Person { PersonId = 4, FullName = "Lê Thị Bảo", Age = 31 },
                               };
    }

    public bool HasPerson(int personId)
    {
        return personCollection.Any(x => x.PersonId == personId);
    }

    public Person GetPerson(int personId)
    {
        if (!HasPerson(personId))
        {
            var error = new CustomFaultMsg { Message = "Không có nhân viên nào với ID là : " + personId };
            throw new FaultException<CustomFaultMsg>(error, error.Message);
        }

        return personCollection.FirstOrDefault(x => x.PersonId == personId);
    }

    public void AddPerson(Person person)
    {
        personCollection.Add(person);
    }

    public Person[] GetAll()
    {
        return personCollection.ToArray();
    }

    public void EditPerson(int personId, Person person)
    {
        Person p = GetPerson(personId);
        p.FullName = person.FullName;
        p.Age = person.Age;
    }

    public void DeletePerson(int personId)
    {
        Person p = GetPerson(personId);
        personCollection.Remove(p);
    }
}
}