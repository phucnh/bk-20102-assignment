﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace StaffClientApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Bam Enter de xem danh sach nhan vien:");
            Console.ReadLine();
            StaffClient.StaffService.StaffClient client = new StaffClient.StaffService.StaffClient();
            Console.WriteLine(client.DisplayStaff());
            Console.WriteLine("\n\n\nChon mot nhan vien de xem ngay sinh:");
            int staffId = int.Parse(Console.ReadLine());
            Console.WriteLine("Nhan vien: " + client.GetFullName(staffId));
            Console.WriteLine("Ngay sinh la: " + client.GetBirthday(staffId));
            Console.WriteLine("\nBam Enter de ket thuc chuong trinh");
            Console.ReadLine();
        }
    }
}
