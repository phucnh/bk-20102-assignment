﻿using System;

namespace StaffService
{
    public class Staff : IStaff
    {
        #region IStaff Members

        public string DisplayStaff()
        {
            return "1. Lê Anh\n2. Trần Văn Bình\n3. Nguyễn Văn Cương\n4. Đinh Văn Dũng";
        }

        public DateTime GetBirthday(int staffId)
        {
            switch (staffId)
            {
                case 1:
                    return new DateTime(1979, 1, 20);
                case 2:
                    return new DateTime(1975, 5, 1);
                case 3:
                    return new DateTime(1967, 2, 26);
                case 4:
                    return new DateTime(1958, 10, 11);
                default:
                    return DateTime.Now;
            }
        }
        
        public string GetFullName(int staffId)
        {
            switch (staffId)
            {
                case 1:
                    return "Lê Anh";
                case 2:
                    return "Trần Văn Bình";
                case 3:
                    return "Nguyễn Văn Cương";
                case 4:
                    return "Đinh Văn Dũng";
                default:
                    return string.Empty;
            }
        }

        #endregion
    }
}
