﻿using System.Runtime.Serialization;
using System.ServiceModel;

namespace ContractSample
{
    [DataContract]
    public class Person
    {
        [DataMember]
        public int PersonId;
        [DataMember]
        public string FullName;
        [DataMember]
        public int Age;
    }
    [ServiceContract]
    public interface IStaffInformation
    {
        [OperationContract]
        bool HasPerson(int personId);
        [OperationContract]
        Person GetPerson(int personId);
        [OperationContract]
        Person[] GetAll();

        [OperationContract(IsOneWay=true]
        void AddPerson(Person person);
        [OperationContract(IsOneWay=true]
        void EditPerson(int personId, Person person);
        [OperationContract(IsOneWay=true]
        void DeletePerson(int personId);
    }
}
