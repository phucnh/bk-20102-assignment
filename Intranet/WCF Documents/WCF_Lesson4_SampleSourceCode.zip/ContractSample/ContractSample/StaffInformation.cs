﻿using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Description;

namespace ContractSample
{
    namespace TCP
    {
        public interface IServiceClass
        {
        }
    }
    public class StaffInformation : IStaffInformation
    {
        List<Person> personCollection = new List<Person>();

        public bool HasPerson(int personId)
        {
            return personCollection.Any(x => x.PersonId == personId);
        }

        public Person GetPerson(int personId)
        {
            return personCollection.FirstOrDefault(x => x.PersonId == personId);
        }

        public void AddPerson(Person person)
        {
            personCollection.Add(person);
        }

        public Person[] GetAll()
        {
            return personCollection.ToArray();
        }

        public void EditPerson(int personId, Person person)
        {
            Person p = GetPerson(personId);
            if (p != null)
            {
                p.FullName = person.FullName;
                p.Age = person.Age;
            }
        }

        public void DeletePerson(int personId)
        {
            Person p = GetPerson(personId);
            if (p != null)
            {
                personCollection.Remove(p);
            }
        }
    }
}
