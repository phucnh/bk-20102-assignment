﻿using System;
using System.ServiceModel;
using System.Windows.Forms;
using AsyncClient.AService;

namespace AsyncClient
{
    public partial class MainForm : Form
    {
        IAsynchronousService client;
        public MainForm()
        {
            InitializeComponent();
            ChannelFactory<IAsynchronousService> factory =
                new ChannelFactory<IAsynchronousService>("AsynchronousService");
            factory.Open();
            client = factory.CreateChannel();
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            int val1 = Convert.ToInt32(inputText1.Text);
            int val2 = Convert.ToInt32(inputText2.Text);

            client.BeginAdd(val1, val2, new AsyncCallback(OnEndAdd), null);
            resultText.Text = "Calculating ...";
        }

        public void OnEndAdd(IAsyncResult asyncResult)
        {
            this.Invoke(
                new MethodInvoker(delegate()
                    {
                        resultText.Text = client.EndAdd(asyncResult).ToString();
                    }));
        }
    }
}
