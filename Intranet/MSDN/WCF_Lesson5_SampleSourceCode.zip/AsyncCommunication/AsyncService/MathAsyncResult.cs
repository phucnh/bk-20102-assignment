﻿using System;

namespace AsyncService
{
    public class MathAsyncResult : AsyncResult
    {
        public int Value1 { get; set; }
        public int Value2 { get; set; }
        public int Result { get; set; }

        public MathAsyncResult(AsyncCallback callback, object state)
            : base (callback, state)
        {
        }
    }
}
