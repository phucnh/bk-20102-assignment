﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace AsyncService
{
    [ServiceContract]
    public interface IAsynchronousService
    {
        [OperationContract(AsyncPattern=true)]
        IAsyncResult BeginAdd(int val1, int val2, AsyncCallback cb, object state);

        int EndAdd(IAsyncResult result);
    }
}
