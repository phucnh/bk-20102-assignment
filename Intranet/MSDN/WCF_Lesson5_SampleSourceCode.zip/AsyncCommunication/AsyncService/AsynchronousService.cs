﻿using System;
using System.ServiceModel;
using System.Threading;

namespace AsyncService
{
    [ServiceBehavior(ConcurrencyMode = ConcurrencyMode.Multiple)]
    public class AsynchronousService : IAsynchronousService
    {
        public IAsyncResult BeginAdd(int val1, int val2, AsyncCallback cb, object state)
        {
            MathAsyncResult asyncResult = new MathAsyncResult(cb, state);
            asyncResult.Value1 = val1;
            asyncResult.Value2 = val2;

            ThreadPool.QueueUserWorkItem(new WaitCallback((Callback)), asyncResult);

            return asyncResult;
        }

        public int EndAdd(IAsyncResult asyncResult)
        {
            int result = 0;

            using (MathAsyncResult mathAsyncResult = asyncResult as MathAsyncResult)
            {
                mathAsyncResult.AsyncWaitHandle.WaitOne();
                result = mathAsyncResult.Result;
            }

            return result;
        }

        public int Add(int value1, int value2)
        {
            Thread.Sleep(1000);
            return value1 + value2;
        }

        private void Callback(object asyncResult)
        {
            MathAsyncResult mathAsyncResult = (MathAsyncResult)asyncResult;
            try
            {
                mathAsyncResult.Result = Add(mathAsyncResult.Value1, mathAsyncResult.Value2);
            }
            finally
            {
                mathAsyncResult.OnCompleted();
            }
        }
    }
}
