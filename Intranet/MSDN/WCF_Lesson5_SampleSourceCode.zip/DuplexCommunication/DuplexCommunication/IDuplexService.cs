﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace DuplexCommunication
{
    [ServiceContract(SessionMode = SessionMode.Required, 
        CallbackContract=typeof(IDuplexServiceCallback))]
    public interface IDuplexService
    {
        [OperationContract(IsOneWay = true)]
        void Add(int bignumber);
        [OperationContract(IsOneWay = true)]
        void Subtract(int bignumber);
    }

    public interface IDuplexServiceCallback
    {
        [OperationContract(IsOneWay = true)]
        void Calculate(int bignumber);
    }
}
