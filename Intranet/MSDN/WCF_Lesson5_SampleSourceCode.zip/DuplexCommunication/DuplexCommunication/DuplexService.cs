﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace DuplexCommunication
{
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.PerSession)]
    public class DuplexService : IDuplexService
    {
        private int answer = 0;
        IDuplexServiceCallback Callback
        {
            get
            {
                return OperationContext.Current.GetCallbackChannel<IDuplexServiceCallback>();
            }
        }

        public void Add(int bignumber)
        {
            answer += bignumber;
            Callback.Calculate(answer);
        }

        public void Subtract(int bignumber)
        {
            answer -= bignumber;
            Callback.Calculate(answer);
        }
    }
}
