﻿using System;
using System.ServiceModel;
using System.Windows.Forms;
using DuplexClient.DService;

namespace DuplexClient
{
    public class ServiceCallback : IDuplexServiceCallback
    {
        private TextBox resultHolder;
        public ServiceCallback(TextBox textbox)
        {
            resultHolder = textbox;
        }

        #region IDuplexServiceCallback Members
        public void Calculate(int bignumber)
        {
            resultHolder.Text = bignumber.ToString();
        }
        #endregion
    }

    public partial class MainForm : Form
    {
        DuplexServiceClient client;

        public MainForm()
        {
            InitializeComponent();
            InstanceContext ic = new InstanceContext(new ServiceCallback(resultText));
            client = new DuplexServiceClient(ic);
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            int value = Convert.ToInt32(inputText.Text);
            client.Add(value);
        }

        private void buttonSubtract_Click(object sender, EventArgs e)
        {
            int value = Convert.ToInt32(inputText.Text);
            client.Subtract(value);
        }
    }
}
